const projectRepository = require('../repositories/project.repository');

class ProjectService {
    async createProject(data, ownerId) {
        return await projectRepository.create({ ...data, ownerId });
    }

    async getProjects(ownerId) {
        return await projectRepository.findAll(ownerId);
    }

    async getProjectById(id) {
        return await projectRepository.findById(id);
    }

    async updateProject(id, data) {
        return await projectRepository.update(id, data);
    }

    async deleteProject(id) {
        return await projectRepository.remove(id);
    }
}

module.exports = new ProjectService();
