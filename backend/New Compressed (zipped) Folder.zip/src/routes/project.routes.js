const express = require("express");
const router = express.Router();
const auth = require("../middlewares/auth.middleware");
const validateInput = require("../middlewares/validate.middleware");
const { z } = require("zod");
const projectController = require("../controllers/project.controller");

const createProjectSchema = z.object({
    name: z.string().min(1, "Project name is required"),
    description: z.string().optional(),
    status: z.enum(["active", "archived", "completed"]).default("active")
});

const updateProjectSchema = createProjectSchema.partial();

router.use(auth.protect);

router.post(
    "/",
    validateInput(createProjectSchema),
    projectController.createProject
);

router.get("/", projectController.getProjects);
router.get("/:id", projectController.getProjectById);
router.put(
    "/:id",
    validateInput(updateProjectSchema),
    projectController.updateProject
);
router.delete("/:id", projectController.deleteProject);

module.exports = router;
