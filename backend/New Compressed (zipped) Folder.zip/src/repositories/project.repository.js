const db = require('../config/db');

class ProjectRepository {
    async create(data) {
        const { name, description, status, ownerId } = data;
        const { rows } = await db.query(
            'INSERT INTO projects (name, description, status, owner_id) VALUES ($1, $2, $3, $4) RETURNING *',
            [name, description || null, status || 'active', ownerId || null]
        );
        return rows[0];
    }

    async findAll(ownerId = null) {
        const params = [];
        const filters = [];

        if (ownerId) {
            params.push(ownerId);
            filters.push(`p.owner_id = $${params.length}`);
        }

        const { rows } = await db.query(`
      SELECT p.*, u.name AS owner_name,
             COUNT(t.id) AS task_count,
             COALESCE(SUM(CASE WHEN t.status = 'Done' THEN 1 ELSE 0 END), 0) AS completed_tasks
      FROM projects p
      LEFT JOIN tasks t ON t.project_id = p.id
      LEFT JOIN users u ON p.owner_id = u.id
      ${filters.length ? 'WHERE ' + filters.join(' AND ') : ''}
      GROUP BY p.id, u.name
      ORDER BY p.created_at DESC
    `, params);
        return rows.map((row) => ({
            ...row,
            task_count: Number(row.task_count),
            completed_tasks: Number(row.completed_tasks)
        }));
    }

    async findById(id) {
        const { rows } = await db.query(`
      SELECT p.*, u.name AS owner_name
      FROM projects p
      LEFT JOIN users u ON p.owner_id = u.id
      WHERE p.id = $1
    `, [id]);
        return rows[0];
    }

    async update(id, data) {
        const { name, description, status } = data;
        const { rows } = await db.query(
            'UPDATE projects SET name = $1, description = $2, status = $3, updated_at = CURRENT_TIMESTAMP WHERE id = $4 RETURNING *',
            [name, description || null, status || 'active', id]
        );
        return rows[0];
    }

    async remove(id) {
        await db.query('DELETE FROM projects WHERE id = $1', [id]);
        return true;
    }
}

module.exports = new ProjectRepository();
