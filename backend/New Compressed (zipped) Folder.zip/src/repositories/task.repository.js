const db = require('../config/db');

class TaskRepository {
    async findAll(filters = {}) {
        const { status, projectId } = filters;
        const params = [];
        const conditions = [];

        if (status) {
            params.push(status);
            conditions.push(`t.status = $${params.length}`);
        }

        if (projectId) {
            params.push(projectId);
            conditions.push(`t.project_id = $${params.length}`);
        }

        const sql = `
      SELECT t.*, p.name AS project_name
      FROM tasks t
      LEFT JOIN projects p ON t.project_id = p.id
      ${conditions.length ? 'WHERE ' + conditions.join(' AND ') : ''}
      ORDER BY t.created_at DESC
    `;

        const { rows } = await db.query(sql, params);
        return rows;
    }

    async create(data) {
        const { title, type, dueDate, due_date, projectId, project_id, assignedUserId, assigned_user_id } = data;
        const dueDateValue = dueDate || due_date || null;
        const projectIdValue = projectId || project_id || null;
        const assignedUserIdValue = assignedUserId || assigned_user_id || null;
        const { rows } = await db.query(
            'INSERT INTO tasks (title, type, status, due_date, project_id, assigned_user_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [title, type, 'Pending', dueDateValue, projectIdValue, assignedUserIdValue]
        );
        return rows[0];
    }

    async update(id, data) {
        const { title, type, due_date, dueDate, projectId, project_id } = data;
        const dueDateValue = due_date || dueDate || null;
        const projectIdValue = projectId || project_id || null;
        const { rows } = await db.query(
            'UPDATE tasks SET title = $1, type = $2, due_date = $3, project_id = $4, updated_at = CURRENT_TIMESTAMP WHERE id = $5 RETURNING *',
            [title, type, dueDateValue, projectIdValue, id]
        );
        return rows[0];
    }

    async updateStatus(id, status) {
        const { rows } = await db.query(
            'UPDATE tasks SET status = $1 WHERE id = $2 RETURNING *',
            [status, id]
        );
        return rows[0];
    }

    async remove(id) {
        await db.query('DELETE FROM tasks WHERE id = $1', [id]);
        return true;
    }
}

module.exports = new TaskRepository();
