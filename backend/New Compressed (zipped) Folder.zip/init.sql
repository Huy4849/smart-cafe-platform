-- PostgreSQL database dump
SET client_encoding = 'UTF8';
SET default_transaction_isolation = 'read committed';
SET timezone = 'UTC';

-- Cleanup old tables if any
DROP TABLE IF EXISTS "tasks" CASCADE;
DROP TABLE IF EXISTS "projects" CASCADE;
DROP TABLE IF EXISTS "users" CASCADE;

-- 1. USERS TABLE
CREATE TABLE "users" (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role VARCHAR(20) DEFAULT 'manager',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. PROJECTS TABLE
CREATE TABLE "projects" (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  status VARCHAR(20) DEFAULT 'active',
  owner_id INTEGER REFERENCES "users"(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. TASKS TABLE
CREATE TABLE "tasks" (
  id SERIAL PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  type VARCHAR(50) DEFAULT 'Task',
  status VARCHAR(20) DEFAULT 'Pending',
  due_date DATE,
  project_id INTEGER REFERENCES "projects"(id) ON DELETE CASCADE,
  assigned_user_id INTEGER REFERENCES "users"(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. NOTES TABLE
CREATE TABLE "notes" (
  id SERIAL PRIMARY KEY,
  content TEXT NOT NULL,
  task_id INTEGER REFERENCES "tasks"(id) ON DELETE CASCADE,
  author_id INTEGER REFERENCES "users"(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data for ProjectFlow
INSERT INTO "users" (name, email, password, role) VALUES
('Project Manager', 'admin@example.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Team Member', 'member@example.com', '$2b$10$.ASGuTgOlDf7WeHrPAqmF.E.hbpiYYwoZYryRaEJ2snk0eU6zvbW.', 'member');

INSERT INTO "projects" (name, description, status, owner_id) VALUES
('ProjectFlow Launch', 'Build the ProjectFlow portfolio application with backend, frontend and Docker.', 'active', 1),
('Website Redesign', 'Refresh the landing pages and product branding.', 'active', 1),
('Automation Sprint', 'Automate deployment and testing workflows for the team.', 'completed', 2);

INSERT INTO "tasks" (title, type, status, due_date, project_id, assigned_user_id) VALUES
('Create project dashboard', 'Development', 'Done', CURRENT_DATE - INTERVAL '2 days', 1, 1),
('Write API documentation', 'Documentation', 'Pending', CURRENT_DATE + INTERVAL '3 days', 1, 2),
('Design project cards', 'Design', 'Pending', CURRENT_DATE + INTERVAL '5 days', 2, 2),
('Prepare launch checklist', 'Planning', 'Done', CURRENT_DATE - INTERVAL '1 day', 1, 1);

INSERT INTO "notes" (content, task_id, author_id) VALUES
('Initial dashboard mockup completed and handed off to design team.', 1, 1),
('Please review the API contract before the next standup.', 2, 2),
('Gather feedback from stakeholders on the card layouts.', 3, 2);
