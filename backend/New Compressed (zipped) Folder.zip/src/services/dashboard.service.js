const dashboardRepository = require('../repositories/dashboard.repository');

class DashboardService {
    async getStats() {
        const [totalProjects, totalTasks, completedTasks, pendingTasks, overdueTasks, chartData, recentTasks] = await Promise.all([
            dashboardRepository.getTotalProjects(),
            dashboardRepository.getTotalTasks(),
            dashboardRepository.getCompletedTasks(),
            dashboardRepository.getPendingTasks(),
            dashboardRepository.getOverdueTasks(),
            dashboardRepository.getTaskStatusBreakdown(),
            dashboardRepository.getRecentTasks()
        ]);

        return {
            totalProjects,
            totalTasks,
            completedTasks,
            pendingTasks,
            overdueTasks,
            chartData,
            recentTasks
        };
    }
}

module.exports = new DashboardService();