const db = require('../config/db');

class DashboardRepository {
    async getTotalProjects() {
        const { rows } = await db.query("SELECT COUNT(*) AS count FROM projects");
        return Array.isArray(rows) && rows.length > 0 ? Number(rows[0].count) : 0;
    }

    async getTotalTasks() {
        const { rows } = await db.query("SELECT COUNT(*) AS count FROM tasks");
        return Array.isArray(rows) && rows.length > 0 ? Number(rows[0].count) : 0;
    }

    async getCompletedTasks() {
        const { rows } = await db.query("SELECT COUNT(*) AS count FROM tasks WHERE status = 'Done'");
        return Array.isArray(rows) && rows.length > 0 ? Number(rows[0].count) : 0;
    }

    async getPendingTasks() {
        const { rows } = await db.query("SELECT COUNT(*) AS count FROM tasks WHERE status = 'Pending'");
        return Array.isArray(rows) && rows.length > 0 ? Number(rows[0].count) : 0;
    }

    async getOverdueTasks() {
        const { rows } = await db.query("SELECT COUNT(*) AS count FROM tasks WHERE status != 'Done' AND due_date < CURRENT_DATE");
        return Array.isArray(rows) && rows.length > 0 ? Number(rows[0].count) : 0;
    }

    async getTaskStatusBreakdown() {
        const { rows } = await db.query(`
      SELECT status AS name, COUNT(*) AS total
      FROM tasks
      GROUP BY status
      ORDER BY status
    `);
        return rows.map((row) => ({ name: row.name, total: Number(row.total) }));
    }

    async getRecentTasks() {
        const { rows } = await db.query(`
      SELECT t.id, t.title, t.status, t.due_date, p.name AS project_name
      FROM tasks t
      LEFT JOIN projects p ON t.project_id = p.id
      ORDER BY t.created_at DESC
      LIMIT 5
    `);
        return rows;
    }
}

module.exports = new DashboardRepository();
